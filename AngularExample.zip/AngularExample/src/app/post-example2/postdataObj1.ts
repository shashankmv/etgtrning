export class postData1{
tid:number | undefined;
tname:string | undefined;
ownerid:number | undefined;
}