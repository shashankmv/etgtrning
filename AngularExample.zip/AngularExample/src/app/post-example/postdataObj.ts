export class postData{
    title:string | undefined;
    body:string | undefined;
    userId:number | undefined;
}