package com.springmvc2.demo;

import java.sql.Connection;

public interface MySQLConnectionInterface {
	public Connection getConnection();
}
