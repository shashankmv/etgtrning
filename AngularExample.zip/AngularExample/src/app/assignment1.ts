import { Component } from "@angular/core";
@Component({
selector:"dig-com",
templateUrl:"./assignment1.html"

})

export class assignment1{
    digits=[1,2,3,4,5];
}