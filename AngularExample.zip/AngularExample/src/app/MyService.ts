export class MyService{
    getName():string{
        return "Shashank"
    }

    getDate():string{
        return "show date"
    }

    getDetails():number{
        return 10;
    }
}