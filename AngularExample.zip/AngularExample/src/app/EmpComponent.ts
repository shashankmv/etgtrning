import { Component } from "@angular/core";

@Component({
    selector:'emp-com',
    template:`
    <div>
    <h1> Another module component </h1>
    </div>`
})
export class EmpComponent{}