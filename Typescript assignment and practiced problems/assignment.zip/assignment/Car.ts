export class Car{
    speed:number;
    regularPrice:number;
    color:string;

    getSalePrice(){
        console.log(this.regularPrice);
    }
}