import { Component } from "@angular/core";
@Component({

    selector:"user-com",
    templateUrl:"./Username.html"
})
export class Username{
    username:string ='Shashank';
    password:string='raina';
}