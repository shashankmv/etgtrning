import { Component } from "@angular/core";
@Component({

    selector:"if-com",
    templateUrl:"./ifexample.html"
})
export class ifexample{
    age:number =18;
}