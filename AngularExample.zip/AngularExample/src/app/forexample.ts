import { Component } from "@angular/core";
@Component({
selector:"for-com",
templateUrl:"./forexample.html"

})

export class forexample{
    heroes=["rajkumar","rajanikanth","chiranjivi","kamalhassan"];
}