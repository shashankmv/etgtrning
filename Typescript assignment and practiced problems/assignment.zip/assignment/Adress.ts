import { Student} from "./Student";
class Adress extends Student{

}

var m1=new Adress(890,"bhavana",36000);

m1.display();