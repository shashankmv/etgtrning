import { NgModule } from "@angular/core";
import  { EmpComponent} from "./EmpComponent";
@NgModule({
    declarations:[EmpComponent],
    imports:[],
    exports:[EmpComponent]
})
export class NewModule{
    
}