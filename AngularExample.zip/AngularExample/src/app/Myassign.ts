export class Myassign{
    getName():string{
        return "Bat"
    }

    getprice():number{
        return 100
    }

    
}